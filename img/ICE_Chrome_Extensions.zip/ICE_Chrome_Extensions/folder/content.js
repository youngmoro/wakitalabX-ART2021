const func = () => {

    // URL
    const path = location.href;

    // pタグを生成(警告文用)
    const bros = document.getElementsByClassName('jss12')[0];
    if (bros.nextElementSibling.tagName !== 'P') {
        const parent = document.getElementById('app');
        const newElement = document.createElement('p');
        newElement.setAttribute('id','new_p');
        parent.insertBefore(newElement, bros.nextSibling);
        const pElem = document.getElementById('new_p');
        pElem.style.fontWeight = 'bold';
        pElem.style.paddingLeft = '2.5%';
        pElem.style.color = 'red';
    }
    
    // 日程登録画面での処理
    if (path.slice(-8) === 'calendar') {
        const pTag = document.getElementById('new_p');
        pTag.innerHTML = '工数1 = 答案1件ではないことに注意してください。大学によって異なりますが、答案1件あたりの工数は0.05~0.15程度になります。'
    }

    // 添削画面, 修正答案提出画面での処理
    if (path.slice(-10) === 'correction' || path.slice(-12) === 'examiner_pos') {
        const pTag = document.getElementById('new_p');
        pTag.innerHTML = '答案の提出期限は表示されている期限の前日の18時であることに注意してください。'

        // table要素を取得
        let tableElem = document.querySelector('table');
        // table要素がない場合は実行しない(答案が0件の場合や, まだ画面の表示が完了していない場合)
        if (tableElem && tableElem.rows[1].cells[0].innerHTML !== '何もありません。') {
            // tableを1行ずつcheck
            const week = ['日', '月', '火', '水', '木', '金', '土'];
            for (let i = 1; i < tableElem.rows.length - 1; i++) {
                // 日付を確認し、月曜締め切りのものは日曜締め切りの表示にする
                let date = tableElem.rows[i].cells[2].innerHTML;
                if (date.slice(-1) !== ')') {
                    let y = date.split('/')[0];
                    let m = date.split('/')[1];
                    let d = date.split('/')[2];
                    let date_obj = new Date(y, m-1, d);
                    tableElem.rows[i].cells[2].innerHTML = `${y}/${m}/${d}(${week[date_obj.getDay()]})`;
                    if (week[date_obj.getDay()] === '月') {
                        tableElem.rows[i].cells[2].innerHTML = `${y}/${m}/${d-1} (日)`;
                        tableElem.rows[i].cells[2].style.color = 'red';
                    }        
                }
        
                // 2回目答案は背景色を変更する
                let name = tableElem.rows[i].cells[5].innerHTML;
                if (name.slice(-3) ===  '第2回') {
                    tableElem.rows[i].cells[5].style.color = 'red';
                    tableElem.rows[i].cells[5].style.fontWeight = 'bold';
                }
            }    
        }
    }
}

// 3秒ごとに実行
setInterval(func, 1000);